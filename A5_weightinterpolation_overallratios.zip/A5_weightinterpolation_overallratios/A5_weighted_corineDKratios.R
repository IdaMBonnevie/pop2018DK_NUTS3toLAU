# Install and import libraries: 
#install.packages("areal")
library(areal)
#install.packages("classInt")
library(classInt)
####install.packages("dplyr")
library(dplyr)
####install.packages("leafem")
library(leafem)
####install.packages("leaflet")
library(leaflet)
####install.packages("mapview")
library(mapview)
####install.packages("Metrics")
library(Metrics)
#install.packages("rstudioapi")
library(rstudioapi)
####install.packages(sf)
library(sf)
####install.packages("tmap")
library(tmap)
l####install.packages("units")
ibrary(units)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Avoid switching to darkmatter basemap but keep default lightgrey basemap when plotting: 
mapviewOptions(basemaps.color.shuffle = FALSE)

# Load spatial data:
NUTS2016withPop2018 <- st_read("data/NUTS_01M_DK2016Pop2018_2017.shp") #source
cor2018 <- st_read("data/cor18_DK_clippedToPop.shp")
LAU2018withPop2018 <- st_read("data/LAU_2018_01M_DK.shp") #target
weightTable <- st_read("data/final_weights_corine_classesDK.csv", options = "DELIMITER=;") #csvWithCorineDensities
corineexplain <- st_read("data/corine_classes.csv", options = "DELIMITER=;") #for corine legend

# ID definitions: 
#NUTS ID is NUTS_ID
#NUTS Population 2018 column is y2018
#CorineID is Code_18
#LAU ID is LAU_ID
#LAU area is AREA_KM2
#LAU population 2018 is POP_2018
#LAU population density 2018 is POP_DENS_2

######---------> MAPVIEW: NUTS and CORINE and LAU:
mapview(NUTS2016withPop2018) + mapview(cor2018) + mapview(LAU2018withPop2018)  

# new AREA COLUMN: calculate NUTS area in km2:
NUTS2016withPop2018$area_nuts <- set_units((st_area(NUTS2016withPop2018)), km^2)
#new DENSITY COLUMN: calculate overall population density per Ha for each nuts:  
NUTS2016withPop2018$densOvHa2018 <- NUTS2016withPop2018$y2018 / (NUTS2016withPop2018$area_nuts * 100) 

# DEFINE Function to make classification break values: 
make_equal_interval <- function(dataset_column_input, amount_intervals, style_type, rounded) {
  # Classify data using n intervals with the style method
  classifications <- classIntervals(dataset_column_input, n = amount_intervals, style = style_type)
  print(style_type)
  print(classifications)
  # Extract the breaks
  breaks <- classifications$brks
  print(breaks)
  # Calculate frequencies of data in each class
  frequencies <- tabulate(findInterval(dataset_column_input, breaks, rightmost.closed = TRUE))
  # Find breaks that result in non-empty classes
  non_empty_breaks <- breaks[frequencies > 0]
  # Round the breaks to divisible by 10 if rounded = TRUE otherwise round to three decimals after comma:
  if (rounded == TRUE) {
    non_empty_breaks <- round(non_empty_breaks, digits = -1)
  } else {
    non_empty_breaks <- round(non_empty_breaks, digits = 3)
  } 
  print(non_empty_breaks)
  # Add min(dataset_column_input) if lower than min(non_empty_breaks)
  if (min(dataset_column_input) < min(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == min(non_empty_breaks)] <- min(dataset_column_input)
  }
  # Add max(dataset_column_input) if higher than max(non_empty_breaks)
  if (max(dataset_column_input) > max(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == max(non_empty_breaks)] <- max(dataset_column_input)
  }
  non_empty_breaks <- sort(unique(non_empty_breaks))
  print(non_empty_breaks)
  return(non_empty_breaks)}
# Define colorpalette default: 
colors_default <- colorRampPalette(c("#FFFF00", "#990000"))  

######---------> MAPVIEW: Show NUTS area size: 
rounded_breaks = c(0, min(NUTS2016withPop2018$area_nuts), max(NUTS2016withPop2018$area_nuts)) #breakvalues
# Extract numeric values from the area catchment units column and store them in a new column
NUTS2016withPop2018$area_nuts_num <- as.numeric(gsub("[^0-9.]", "", NUTS2016withPop2018$area_nuts))
mapview(NUTS2016withPop2018, zcol = "area_nuts_num", col.regions = colors_default, at = rounded_breaks, layer.name="NUTS area in km2") %>%
  addStaticLabels(NUTS2016withPop2018,
                  NUTS2016withPop2018$area_nuts,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))
######---------> MAPVIEW: Show NUTS population: 
rounded_breaks = c(0, min(NUTS2016withPop2018$y2018), max(NUTS2016withPop2018$y2018)) #breakvalues
mapview(NUTS2016withPop2018, zcol = "y2018", col.regions = colors_default, at = rounded_breaks, layer.name="NUTS 2018 population") %>%
  addStaticLabels(NUTS2016withPop2018,
                  NUTS2016withPop2018$y2018,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))
######---------> MAPVIEW: Show NUTS population density: 
rounded_breaks = c(0, min(NUTS2016withPop2018$densOvHa2018), max(NUTS2016withPop2018$densOvHa2018)) #breakvalues
mapview(NUTS2016withPop2018, zcol = "densOvHa2018", col.regions = colors_default, at = rounded_breaks, layer.name="NUTS 2018 population density per ha") %>%
  addStaticLabels(NUTS2016withPop2018,
                  NUTS2016withPop2018$densOvHa2018,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))


############## PROCESSING OF CORINE DATA ##############
# Get corine class names: 
cor_names <- cor2018 %>%
  left_join(corineexplain, by = c("Code_18" = "code_18"))

######---------> MAPVIEW: CORINE classes plotted using Leaflet to get the right colours in legend: 
# Create the map using mapview
map <- mapview(cor_names, zcol =  "CodeName", col.regions = cor_names$colorpal, layer.name="corine classes")
# Extract the underlying leaflet map
leaflet_map <- map@map
# Get unique CodeName and colorpal pairs
unique_classes <- cor_names %>%
  distinct(CodeName, colorpal)
# Add a custom legend to the leaflet map with unique classes
leaflet_map <- leaflet_map %>%
  addLegend(
    position = "bottomright",
    colors = unique_classes$colorpal,
    labels = unique_classes$CodeName,
    title = "Corine Classes",
    opacity = 1
  )
# Display the map with the custom legend
leaflet_map

# Merge the CSV weight data with the spatial corine object
cor_detailed <- cor_names %>%
  left_join(weightTable, by = c("Code_18" = "code_18"))

# Calculate intersection of residential corine and nuts population (first intersection): 
nuts_cor_intersect <- st_intersection(cor_detailed, NUTS2016withPop2018)

# Convert percentage from string to numeric: 
nuts_cor_intersect$percentdistribution <- as.numeric(nuts_cor_intersect$percentdistribution)

######---------> MAPVIEW: CORINE classes + percent weights: 
map_list <- c(mapview(cor_names, zcol =  "CodeName", col.regions = cor_names$colorpal, layer.name="corine classes"))
Reduce(`+`, map_list)
map_list <- c(map_list, 
              mapview(nuts_cor_intersect, zcol =  "percentdistribution", layer.name="percent weights to use"))
Reduce(`+`, map_list)

# new ID column
nuts_cor_intersect$nuts_cor_id <- interaction(nuts_cor_intersect$NUTS_ID, nuts_cor_intersect$Code_18)

# Get unique corine weights per NUTS ID
table_unique_weights <- nuts_cor_intersect %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(nuts_cor_id, NUTS_ID, percentdistribution) %>%
  mutate(percentdistribution = as.numeric(percentdistribution)) %>%
  group_by(nuts_cor_id) %>%
  summarize(percUnique = first(percentdistribution), 
            NUTS_ID = first(NUTS_ID)) 

# Sum weights per NUTS ID
table_sum_of_weights <- table_unique_weights %>%
  select(NUTS_ID, percUnique) %>%
  group_by(NUTS_ID) %>%
  summarize(percSum = sum(percUnique)) 

# Merge the sum of weight data with the nuts data
nuts_cor_weights <- nuts_cor_intersect %>%
  left_join(table_sum_of_weights, by = "NUTS_ID")

######---------> MAPVIEW: Show nuts sum of percent weights: 
mapview(nuts_cor_weights, zcol =  "percSum", layer.name="nuts sum of percent weights to use")

# new AREA COLUMN: calculate intersection area in km2:
nuts_cor_weights$area_cor <- set_units((st_area(nuts_cor_weights)), km^2)

# Sum area per corine category per NUTS ID (necessary if multiple polygons for same corine category is present in a nuts):
table_area_corine <- nuts_cor_weights %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(nuts_cor_id, area_cor) %>%
  mutate(area_cor = as.numeric(area_cor)) %>%
  group_by(nuts_cor_id) %>%
  summarize(area_corSum = sum(area_cor)) 

# Merge overall corine category per nuts area data with the nuts data
nuts_cor_new <- nuts_cor_weights %>%
  left_join(table_area_corine, by = "nuts_cor_id")

######---------> MAPVIEW: Show km2 per corine category per nuts + per corine polygon per nuts: 
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_new$area_corSum), 4, "equal", rounded = TRUE) #breakvalues
nuts_cor_new$area_corSum_num <- as.numeric(gsub("[^0-9.]", "", nuts_cor_new$area_corSum))
map_list <- c(mapview(nuts_cor_new, zcol = "area_corSum_num", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="total km2 per corine category per nuts",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_new$area_cor), 4, "equal", rounded = TRUE) #breakvalues
nuts_cor_new$area_cor_num <- as.numeric(gsub("[^0-9.]", "", nuts_cor_new$area_cor))
map_list <- c(map_list, mapview(nuts_cor_new, zcol = "area_cor_num", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="km2 per corine polygon per nuts",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)

# estimated final corine category weight:
nuts_cor_new$newWeight <- (as.numeric(nuts_cor_new$percentdistribution) / #specific corine weight
                             nuts_cor_new$percSum * # sum of all corine weights present in that nuts
                             100.) #percentage

######---------> MAPVIEW: Show normalised weight + original weight per corine polygon per nuts: 
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_new$newWeight), 4, "equal", rounded = TRUE) #breakvalues
map_list <- c(mapview(nuts_cor_new, zcol = "newWeight", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="normalised weight percent per corine category",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_new$percentdistribution), 4, "equal", rounded = TRUE) #breakvalues
map_list <- c(map_list, mapview(nuts_cor_new, zcol = "percentdistribution", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="original weight percent per corine category",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)

# Get unique normalised corine weights per NUTS ID
table_unique_norm_weights <- nuts_cor_new %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(nuts_cor_id, NUTS_ID, newWeight) %>%
  group_by(nuts_cor_id) %>%
  summarize(newWeightUnique = first(newWeight), 
            NUTS_ID = first(NUTS_ID)) 

# Sum normalised weights per NUTS ID
table_sum_of_norm_weights <- table_unique_norm_weights %>%
  select(NUTS_ID, newWeightUnique) %>%
  group_by(NUTS_ID) %>%
  summarize(newWeightSum = sum(newWeightUnique)) 

# Merge the sum of normalised weight data with the nuts data
nuts_cor_norm <- nuts_cor_new %>%
  left_join(table_sum_of_norm_weights, by = "NUTS_ID")

######---------> MAPVIEW: Show nuts sum of normalised percent weights: 
rounded_breaks <- c(0,100) #breakvalues
map_list <- c(mapview(nuts_cor_norm, zcol = "newWeightSum", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="nuts sum of normalised percent weights",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
#unique(nuts_cor_norm$newWeightSum)

#new column with corine area multiplied the normalised corine weight (draft area-based weights):  
nuts_cor_norm$areaWeight <- nuts_cor_norm$newWeight * nuts_cor_norm$area_cor #the 100 is to remove the percentage confusion

# Get sum of area-based weights for each nuts 
table_area_weights <- nuts_cor_norm %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(NUTS_ID, areaWeight) %>%
  group_by(NUTS_ID) %>%
  summarize(areaWeightSum = sum(areaWeight)) 

# Merge the area-based weights data with the pop data
nuts_cor_final <- nuts_cor_norm %>%
  left_join(table_area_weights, by = "NUTS_ID")

######---------> MAPVIEW: Show upper part of area-based weights: 
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_final$areaWeight), 2, "jenks", rounded = TRUE) #breakvalues
map_list <- c(mapview(nuts_cor_final, zcol = "areaWeight", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="upper part of area-based weights",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)

######---------> MAPVIEW: Show lower part of area-based weights: sum of area-based weights: 
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_final$areaWeightSum), 2, "jenks", rounded = TRUE) #breakvalues
map_list <- c(mapview(nuts_cor_final, zcol = "areaWeightSum", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="lower part of area-based weights (sum)",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)

# New column with full area-based weights:  
nuts_cor_final$areaWeightFull <- nuts_cor_final$areaWeight / nuts_cor_final$areaWeightSum 

######---------> MAPVIEW: Show full area-based weights: 
mapview(nuts_cor_final, zcol = "areaWeightFull", col.regions = colors_default, layer.name="final area-based weights")

# New column with estimated population per corine polygon:  
nuts_cor_final$estPopCor <- nuts_cor_final$y2018 * nuts_cor_final$areaWeightFull
#sum(nuts_cor_final$estPopCor) = 1007911, sum of 461852 and 546059 yay! 
#sum(unique(nuts_cor_final$y2018)) = 1007911

######---------> MAPVIEW: Show estimated 2018 population per corine polygon: 
rounded_breaks <- make_equal_interval(as.numeric(nuts_cor_final$estPopCor), 2, "jenks", rounded = TRUE) #breakvalues
map_list <- c(mapview(nuts_cor_final, zcol = "estPopCor", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="Estimated 2018 population per corine polygon",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
#sum(nuts_cor_final$estPopCor)

# Check: Calculate estimated population at NUTS level to check match:   
population_nuts_estimated <- nuts_cor_final %>%
  select(NUTS_ID, estPopCor) %>%
  group_by(NUTS_ID) %>%
  summarize(popNutsEst = sum(estPopCor)) 

######---------> MAPVIEW: Show estimated 2018 population at NUTS level as a check: 
rounded_breaks <- make_equal_interval(as.numeric(population_nuts_estimated$popNutsEst), 2, "jenks", rounded = TRUE) #breakvalues
map_list <- c(mapview(population_nuts_estimated, zcol = "popNutsEst", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="Estimated 2018 population at NUTS level",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)


############## AREA INTERPOLATION ##############
# new ID column to create unique id (some corine categories are divided by nuts borders)
nuts_cor_final$id_cor2 <- interaction(nuts_cor_final$NUTS_ID, nuts_cor_final$ID)

# aw_interpolate to interpolate corine pop to lau level: 
estimated_lau_pop <- aw_interpolate(
  .data = LAU2018withPop2018, #referred to as target elsewhere
  tid = "LAU_ID", #id column in target
  source = nuts_cor_final,
  sid = "id_cor2", #id column in source
  weight = "sum", #should be sum for intensive vs. extensive interpolations
  output = "sf",
  extensive = "estPopCor" #attribute in source to interpolate 
)

######---------> MAPVIEW: Show estimated 2018 population at LAU level: 
rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$estPopCor), 2, "jenks", rounded = TRUE) #breakvalues
map_list <- c(mapview(estimated_lau_pop, zcol = "estPopCor", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="Estimated 2018 population at LAU level",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
#sum(estimated_lau_pop$estPopCor)
#sum(nuts_cor_final$estPopCor)


############## COMPARE WITH LAU ##############
######---------> MAPVIEW: LAU DETAILS: AREA + POPULATION + DENSITY   
rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$AREA_KM2), 4, "equal", rounded = TRUE) #breakvalues
# Extract numeric values from the area units column and store them in a new column
LAU2018withPop2018$AREA_KM2_num <- as.numeric(gsub("[^0-9.]", "", LAU2018withPop2018$AREA_KM2))
map_list <- c(mapview(LAU2018withPop2018, zcol = "AREA_KM2_num", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="LAU area in km2",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$POP_2018), 4, "equal", rounded = TRUE) #breakvalues
map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "POP_2018", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="LAU population 2018",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$POP_DENS_2), 4, "jenks", rounded = FALSE) #breakvalues
map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "POP_DENS_2", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="LAU population density per km2 in 2018",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)

######---------> MAPVIEW: stated population per LAU + estimated population per LAU  
rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$POP_2018), 4, "jenks", rounded = FALSE) #breakvalues
map_list <- c(mapview(estimated_lau_pop, zcol = "POP_2018", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="LAU population 2018",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$estPopCor), 3, "jenks", rounded = FALSE) #breakvalues
map_list <- c(map_list, mapview(estimated_lau_pop, zcol = "estPopCor", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="Estimated population 2018 per LAU",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)

# Calculate percentage overestimation (marked with plus) or underestimation (marked with minus) of estimated population 
estimated_lau_pop$pop2018dif <- ((-(estimated_lau_pop$POP_2018 - as.numeric(estimated_lau_pop$estPopCor)) / estimated_lau_pop$POP_2018) *100.)

###### FINAL TMAP 1: Map with over and underestimations     
# Specify final classification and colors 
#Specify percentage interval to use as classification: 
rounded_breaks <- c(min(estimated_lau_pop$pop2018dif), -50, -30, -20, -10, -5, 0, 5, 10, 20, 30, 50, max(estimated_lau_pop$pop2018dif))
#colorpalette for this percentage interval: 
colors_much_below_zero <- colorRampPalette(c("#C06463", "#FD9763"))  # Light red to dark red
colors_below_zero <- colorRampPalette(c("#DDC511", "#FDFD63"))  # Light yellow to dark yellow #overestimation #FBDA62
colors_above_zero <- colorRampPalette(c("#B2DDFC", "#648BD7"))  # Light yellow to dark yellow #7A9BDC
colors_much_above_zero <- colorRampPalette(c("#AF4EB6", "#7D4195"))  # Light yellow to dark yellow ##7669D3 #5548A6
#Generate number of colors needed: 
num_colors_much_below <- 2 # sum(rounded_breaks < -30)
num_colors_below <- 4 # sum(rounded_breaks <= 5)
num_colors_above <- 4
num_colors_much_above <- 2 #sum(rounded_breaks > 30)
#create specific color palettes: 
colors_much_below <- colors_much_below_zero(num_colors_much_below)
colors_below <- colors_below_zero(num_colors_below)
colors_above <- colors_above_zero(num_colors_above)
colors_much_above <- colors_much_above_zero(num_colors_much_above)
#Concatenate the two lists
final_colors <- c(colors_much_below, colors_below, colors_above, colors_much_above)
# DEFINE Function to make classification break values: 
create_bbox <- function(dataset_input, justXmin, justXmax, justYmin, justYmax) {
  bbox_new <- st_bbox(dataset_input)
  xrange <- bbox_new$xmax - bbox_new$xmin # range of x values
  yrange <- bbox_new$ymax - bbox_new$ymin # range of y values
  bbox_new[1] <- (bbox_new[1] - (justXmin * xrange)) # xmin - left
  bbox_new[3] <- bbox_new[3] + (justXmax * xrange) # xmax - right
  bbox_new[2] <- bbox_new[2] - (justYmin * yrange) # ymin - bottom
  bbox_new[4] <- bbox_new[4] + (justYmax * yrange) # ymax - top
  bbox_new <- bbox_new %>%  # take the bounding box ...
    st_as_sfc() # ... and make it a sf polygon
  return(bbox_new)}
######---------> TMAP: Over and underestimation of population    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_percDif_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "pop2018dif", 
              title = "Under/Overestimation\nErrors in %",
              midpoint = 0, 
              breaks = rounded_breaks, 
              palette = final_colors) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nusing ratios",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_percDif_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_percDif_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "pop2018dif", 
              legend.show = FALSE,
              midpoint = 0, 
              breaks = rounded_breaks, 
              palette = final_colors 
  ) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_percDif_Born, 
      vp = grid::viewport(x = 0.71, y = 0.5,
                          width = 0.2, 
                          height = 0.2)
)

# KEY DENSITY COLUMN: estimated LAU population density in km2:  
estimated_lau_pop$densKm2Est <- as.numeric(estimated_lau_pop$estPopCor) / estimated_lau_pop$AREA_KM2 

###### FINAL TMAP 2A: Map with estimated population density --- NATURAL BREAKS     
# Estimated population density     
rounded_breaks <- c(15., 110., 250., 560., 880., 1420., 1780., 2360., 3240., 6730., 11982.)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
######---------> TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#FFBA66", "#FF6600", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nusing ratios",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#FFBA66", "#FF6600", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.71, y = 0.46,
                          width = 0.2, 
                          height = 0.2)
)

###### FINAL TMAP 2A: Map with estimated population density --- QUANTILE     
# Estimated population density     
rounded_breaks <- c(15., 50., 70., 80., 120., 160., 460., 1120., 11982.)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
######---------> TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nusing ratios",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.71, y = 0.5,
                          width = 0.2, 
                          height = 0.2)
)

############## PRINT STATEMENTS ##############
######---------> PRINT     
cat("Population 2018 total for NUTS is:", sum(NUTS2016withPop2018$y2018)) 
cat("Population 2018 total for LAU is:", sum(LAU2018withPop2018$POP_2018))
cat("Population 2018 is estimated to be:", sum(estimated_lau_pop$corPop))
cat("Population 2018 total for LAU according to estimated data is:", sum(estimated_lau_pop$POP_2018))

# Print overall population: 
######---------> PRINT
cat("Overall percentage error:", sum(abs(estimated_lau_pop$pop2018dif)))
cat("Overall percentage error average:", sum(estimated_lau_pop$pop2018dif))
cat("Mean signed deviation or Bias:", bias(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Mean absolute error:", mae(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Median absolute error:", mdae(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Mean squared error:", mse(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Root mean squared error:", rmse(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Mean absolute percentage error:", mape(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
