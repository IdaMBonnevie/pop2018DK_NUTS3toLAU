# Install and import libraries: 
##install.packages("dplyr")
library(dplyr)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)

# Load spatial data:
pop2021 <- st_read("data/pop1km2_DK.shp")
cor2018 <- st_read("data/cor18_DK_clippedToPop.shp")
bbr_many_columns_new <- st_read("data/bbr2018newest.geojson") # BBR_res >= 2018
bbr_new_draft <- bbr_many_columns_new[, c("byg021BygningensAnvendelse", "byg026OpFoerelsesAar", "byg039BygningensSamlBoligAreal")]
names(bbr_new_draft) <- c("bbr_use", "bbr_year", "bbr_bolig", "geometry")
bbr_new_draft$ID_bbr_new = 1
bbr_new <- st_transform(bbr_new_draft, st_crs(pop2021))
bbr_many_columns_old <- st_read("data/bbr2017oldest.geojson") # BBR_res >= 2018
bbr_old_draft <- bbr_many_columns_old[, c("byg021BygningensAnvendelse", "byg026OpFoerelsesAar", "byg039BygningensSamlBoligAreal")]
names(bbr_old_draft) <- c("bbr_use", "bbr_year", "bbr_bolig", "geometry")
bbr_old_draft$ID_bbr_old = 1
bbr_old <- st_transform(bbr_old_draft, st_crs(pop2021))

# Calculate area in ha and and people_dens of pop2021: 
pop2021$area_ha <- st_area(pop2021$geometry/100)  # 1 km2 = 100 hectare
pop2021$DensHa <- pop2021$OBS_VALUE_/pop2021$area_ha

# NEW BBR: 
# Calculate intersection between pop and bbr_new1 
intersection_result1new <- st_intersection(pop2021, bbr_new)

# Extract attributes from intersection sf object and convert to data frame:
attributes_pop_bbr_new <- st_drop_geometry(intersection_result1new)

# Group features by pop_id_column and sum bbr bolig_m2 in statistics table:
table_pop_bbr_new <- attributes_pop_bbr_new %>%
  select(GRD_ID, bbr_bolig) %>%
  group_by(GRD_ID) %>%
  summarize(newboligsum = sum(bbr_bolig))

# OLD BBR: 
# Calculate intersection between pop and bbr_old1 
intersection_result1old <- st_intersection(pop2021, bbr_old)

# Extract attributes from intersection sf object and convert to data frame:
attributes_pop_bbr_old <- st_drop_geometry(intersection_result1old)

# Group features by pop_id_column and sum bbr bolig_m2 in statistics table:
table_pop_bbr_old <- attributes_pop_bbr_old %>%
  select(GRD_ID, bbr_bolig) %>%
  group_by(GRD_ID) %>%
  summarize(oldboligsum = sum(bbr_bolig))

# Calculate bolig_m2 percentage: 
table_pop_bbr <- table_pop_bbr_old %>%
  full_join(table_pop_bbr_new, by = "GRD_ID") %>%
  mutate(boligperc = case_when(
    is.na(oldboligsum) & is.na(newboligsum) ~ 0, #if oldboligsum=NA AND newboligsum=NA
    is.na(newboligsum) ~ 1.0, #if only newboligsum=NA 
    is.na(oldboligsum) ~ 0, # if only oldboligsum=NA
    TRUE ~ oldboligsum / (oldboligsum + newboligsum) # if neither oldboligsum=NA nor newboligsum=NA 
  )) %>%
  select(GRD_ID, boligperc)

#Modify pop from 2021 to 2018 based on BBR old/new bolig_m2 ratio 
pop_modified <- pop2021 %>%
  left_join(table_pop_bbr, by = "GRD_ID") %>%
  mutate(
    area_ha = as.numeric(area_ha),
    DensHa = as.numeric(DensHa),
  ) %>%
  mutate(pop18mod = case_when(
  is.na(boligperc) ~ OBS_VALUE_,    # Condition a
    TRUE ~ boligperc * OBS_VALUE_   # Condition b
  ))

# Calculate intersection
intersection_result <- st_intersection(pop_modified, cor2018)

# Calculate area in ha of intersection: 
intersection_result$area_ha_int <- st_area(intersection_result$geometry/100)  # 1 km2 = 100 hectare

# Calculate percent area of intersection: 
intersection_result$percentarea <- intersection_result$area_ha_int/intersection_result$area_ha

# Calculate percent people of intersection: 
intersection_result$people <- intersection_result$percentarea*intersection_result$pop18mod

# Calculate people per CORINE category and area per CORINE category 
aggregated_People <- aggregate(people ~ Code_18, intersection_result, FUN = sum)
aggregated_Area <- aggregate(area_ha_int ~ Code_18, intersection_result, FUN = sum)

# Join the two aggregated tables together
joined_data <- full_join(aggregated_People, aggregated_Area, by = "Code_18")

# Calculate people density:
joined_data$density <- joined_data$people/joined_data$area_ha_int
joined_data$percentdistribution <- joined_data$density/sum(joined_data$density)*100

# Write table to textfile: 
write.table(joined_data, file = "cor_DK.txt", sep = "\t", row.names = TRUE, quote = FALSE)
print("file written")


