A bbr2017oldest.geojson and bbr2018newest.geojson need to be produced an inputted in this folder. 

BBR can be produced by downloading the Danish Central Register of Building and Dwellings (BBR): 
https://datafordeler.dk/dataoversigt/bygnings-og-boligregistret-bbr/bbr-fildownload/
Our version that this script has been based on was produced based on a BBR dataset downloaded Spring 2024.

To produce bbr2017oldest.geojson, then remove all buildings built later than 2018 with this SQL query: 
("byg021BygningensAnvendelse"= 110 OR  "byg021BygningensAnvendelse"  =  120 OR "byg021BygningensAnvendelse"  =  121 OR "byg021BygningensAnvendelse"  =  122 OR  "byg021BygningensAnvendelse"  =  130 OR "byg021BygningensAnvendelse"  =  131 OR "byg021BygningensAnvendelse"  =  132 OR "byg021BygningensAnvendelse" = 140 OR "byg021BygningensAnvendelse" = 150 OR "byg021BygningensAnvendelse" = 160 OR  "byg021BygningensAnvendelse" = 185 OR "byg021BygningensAnvendelse" = 190) AND"byg026OpFoerelsesAar" <= 2017

To produce bbr2018newest.geojson, then remove all buildings built before 2018 with this SQL query: 
  and contains the building resulting from the following query: 
("byg021BygningensAnvendelse"= 110 OR  "byg021BygningensAnvendelse"  =  120 OR "byg021BygningensAnvendelse"  =  121 OR "byg021BygningensAnvendelse"  =  122 OR  "byg021BygningensAnvendelse"  =  130 OR "byg021BygningensAnvendelse"  =  131 OR "byg021BygningensAnvendelse"  =  132 OR "byg021BygningensAnvendelse" = 140 OR "byg021BygningensAnvendelse" = 150 OR "byg021BygningensAnvendelse" = 160 OR  "byg021BygningensAnvendelse" = 185 OR "byg021BygningensAnvendelse" = 190) AND"byg026OpFoerelsesAar" >= 2018
