  # Install and import libraries: 
  #install.packages("areal")
  library(areal)
  #install.packages("classInt")
  library(classInt)
  ####install.packages("dplyr")
  library(dplyr)
  ####install.packages("leafem")
  library(leafem)
  ####install.packages("mapview")
  library(mapview)
  ####install.packages("Metrics")
  library(Metrics)
  #install.packages("rstudioapi")
  library(rstudioapi)
  ####install.packages(sf)
  library(sf)
  ####install.packages("tmap")
  library(tmap)
  l####install.packages("units")
  ibrary(units)
  
  # Set directory to script directory: 
  script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
  setwd(script_directory)
  
  # Avoid switching to darkmatter basemap but keep default lightgrey basemap when plotting: 
  mapviewOptions(basemaps.color.shuffle = FALSE)
  
  # Load spatial data:
  cor2018 <- st_read("data/cor18_DK_clippedToPop.shp")
  LAU2018withPop2018 <- st_read("data/LAU_2018_01M_DK.shp") #target
  weightTable <- st_read("data/final_weights_corine_classesDK.csv", options = "DELIMITER=;") #csvWithCorineDensities
  corineexplain <- st_read("data/corine_classes.csv", options = "DELIMITER=;") #for corine legend
  
  # ID definitions: 
  #CorineID is Code_18
  #LAU ID is LAU_ID
  #LAU area is AREA_KM2
  #LAU population 2018 is POP_2018
  #LAU population density 2018 is POP_DENS_2
  
  ######---------> MAPVIEW: NUTS and CORINE and LAU:
  mapview(cor2018) + mapview(LAU2018withPop2018)  

  # DEFINE Function to make classification break values: 
  make_equal_interval <- function(dataset_column_input, amount_intervals, style_type, rounded) {
    # Classify data using n intervals with the style method
    classifications <- classIntervals(dataset_column_input, n = amount_intervals, style = style_type)
    print(style_type)
    print(classifications)
    # Extract the breaks
    breaks <- classifications$brks
    print(breaks)
    # Calculate frequencies of data in each class
    frequencies <- tabulate(findInterval(dataset_column_input, breaks, rightmost.closed = TRUE))
    # Find breaks that result in non-empty classes
    non_empty_breaks <- breaks[frequencies > 0]
    # Round the breaks to divisible by 10 if rounded = TRUE otherwise round to three decimals after comma:
    if (rounded == TRUE) {
      non_empty_breaks <- round(non_empty_breaks, digits = -1)
    } else {
      non_empty_breaks <- round(non_empty_breaks, digits = 3)
    } 
    print(non_empty_breaks)
    # Add min(dataset_column_input) if lower than min(non_empty_breaks)
    if (min(dataset_column_input) < min(non_empty_breaks)) {
      non_empty_breaks[non_empty_breaks == min(non_empty_breaks)] <- min(dataset_column_input)
    }
    # Add max(dataset_column_input) if higher than max(non_empty_breaks)
    if (max(dataset_column_input) > max(non_empty_breaks)) {
      non_empty_breaks[non_empty_breaks == max(non_empty_breaks)] <- max(dataset_column_input)
    }
    non_empty_breaks <- sort(unique(non_empty_breaks))
    print(non_empty_breaks)
    return(non_empty_breaks)}
  # Define colorpalette default: 
  colors_default <- colorRampPalette(c("#FFFF00", "#990000"))  
  
  
  ############## PROCESSING OF CORINE DATA ##############
  # Get corine class names: 
  cor_subset <- cor2018 %>%
    left_join(corineexplain, by = c("Code_18" = "code_18"))
  
  ######---------> MAPVIEW: CORINE classes: 
  mapview(cor_subset, zcol =  "CodeName", col.regions = cor_subset$colorpal, layer.name="corine classes")
  
  # Merge the CSV weight data with the spatial corine object
  cor_detailed <- cor_subset %>%
    left_join(weightTable, by = c("Code_18" = "code_18"))
  
  ######---------> MAPVIEW: Show density weights: 
  mapview(cor_detailed, zcol =  "density", layer.name="density weights to use")
  
  
  ############## AREA INTERPOLATION ##############
  cor_intersect <- st_intersection(cor_detailed, LAU2018withPop2018)
  
  # new AREA COLUMN: calculate intersected corine area in km2:
  cor_intersect$area_cor <- set_units((st_area(cor_intersect)), km^2)
  
  ######---------> MAPVIEW: Estimated 2018 population per conrine intersection category: 
  mapview(cor_intersect, zcol = "area_cor", layer.name="intersected CORINE area in km2")
  
  #new population per corine intersection polygon:  
  cor_intersect$corPop <- as.numeric(cor_intersect$density) * (cor_intersect$area_cor * 100) 
  
  ######---------> MAPVIEW: Estimated 2018 population per conrine intersection category: 
  mapview(cor_intersect, zcol = "corPop", layer.name="estimated 2018 population per intersected corine category")
  
  # Group pop by LAU ID:
  estimated_lau_pop <- cor_intersect %>%
    select(LAU_ID, POP_2018, AREA_KM2, POP_DENS_2, corPop, area_cor, geometry) %>%
    group_by(LAU_ID) %>%
    summarize(POP_2018 = first(POP_2018),
              AREA_KM2 = first(AREA_KM2),
              POP_DENS_2 = first(POP_DENS_2),
              corPop = sum(as.numeric(corPop)),
              area_cor = sum(area_cor),
              geometry = st_union(geometry))
  
  # replace NA with 0 in estimated pop
  #estimated_lau_pop$corPop[is.na(estimated_lau_pop$corPop)] <- 0
  # replace NA with 0 in estimated area
  #estimated_lau_pop$area_cor[is.na(estimated_lau_pop$area_cor)] <- 0
  
  mapview(estimated_lau_pop, zcol = "corPop", layer.name="estimated 2018 population per LAU")
  
  ############## COMPARE WITH LAU ##############
  ######---------> MAPVIEW: LAU DETAILS: AREA + POPULATION + DENSITY   
  rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$AREA_KM2), 4, "equal", rounded = TRUE) #breakvalues
  # Extract numeric values from the area units column and store them in a new column
  LAU2018withPop2018$AREA_KM2_num <- as.numeric(gsub("[^0-9.]", "", LAU2018withPop2018$AREA_KM2))
  map_list <- c(mapview(LAU2018withPop2018, zcol = "AREA_KM2_num", col.regions = colors_default, 
                        at = rounded_breaks, layer.name="LAU area in km2",
                        alpha.regions = 0.75))
  Reduce(`+`, map_list)
  rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$POP_2018), 4, "equal", rounded = TRUE) #breakvalues
  map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "POP_2018", col.regions = colors_default, 
                                  at = rounded_breaks, layer.name="LAU population 2018",
                                  alpha.regions = 0.75))
  Reduce(`+`, map_list)
  rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$POP_DENS_2), 4, "jenks", rounded = FALSE) #breakvalues
  map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "POP_DENS_2", col.regions = colors_default, 
                                  at = rounded_breaks, layer.name="LAU population density per km2 in 2018",
                                  alpha.regions = 0.75))
  Reduce(`+`, map_list)
  
  ######---------> MAPVIEW: stated population per LAU + estimated population per LAU  
  rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$POP_2018), 4, "jenks", rounded = FALSE) #breakvalues
  map_list <- c(mapview(estimated_lau_pop, zcol = "POP_2018", col.regions = colors_default, 
                        at = rounded_breaks, layer.name="LAU population 2018",
                        alpha.regions = 0.75))
  Reduce(`+`, map_list)
  rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$corPop), 4, "jenks", rounded = FALSE) #breakvalues
  map_list <- c(map_list, mapview(estimated_lau_pop, zcol = "corPop", col.regions = colors_default, 
                                  at = rounded_breaks, layer.name="Estimated population 2018 per LAU",
                                  alpha.regions = 0.75))
  Reduce(`+`, map_list)
  
  # Calculate percentage overestimation (marked with plus) or underestimation (marked with minus) of estimated population 
  estimated_lau_pop$pop2018dif <- ((-(estimated_lau_pop$POP_2018 - as.numeric(estimated_lau_pop$corPop)) / estimated_lau_pop$POP_2018) *100.)
  
  ###### FINAL TMAP 1: Map with over and underestimations     
  # Specify final classification and colors 
  #Specify percentage interval to use as classification: 
  rounded_breaks <- c(min(estimated_lau_pop$pop2018dif), -50, -30, -20, -10, -5, 0, 5, 10, 20, 30, 50, max(estimated_lau_pop$pop2018dif))
  #colorpalette for this percentage interval: 
  colors_much_below_zero <- colorRampPalette(c("#C06463", "#FD9763"))  # Light red to dark red
  colors_below_zero <- colorRampPalette(c("#DDC511", "#FDFD63"))  # Light yellow to dark yellow #overestimation #FBDA62
  colors_above_zero <- colorRampPalette(c("#B2DDFC", "#648BD7"))  # Light yellow to dark yellow #7A9BDC
  colors_much_above_zero <- colorRampPalette(c("#AF4EB6", "#7D4195"))  # Light yellow to dark yellow ##7669D3 #5548A6
  #Generate number of colors needed: 
  num_colors_much_below <- 2 # sum(rounded_breaks < -30)
  num_colors_below <- 4 # sum(rounded_breaks <= 5)
  num_colors_above <- 4
  num_colors_much_above <- 2 #sum(rounded_breaks > 30)
  #create specific color palettes: 
  colors_much_below <- colors_much_below_zero(num_colors_much_below)
  colors_below <- colors_below_zero(num_colors_below)
  colors_above <- colors_above_zero(num_colors_above)
  colors_much_above <- colors_much_above_zero(num_colors_much_above)
  #Concatenate the two lists
  final_colors <- c(colors_much_below, colors_below, colors_above, colors_much_above)
  # DEFINE Function to make classification break values: 
  create_bbox <- function(dataset_input, justXmin, justXmax, justYmin, justYmax) {
    bbox_new <- st_bbox(dataset_input)
    xrange <- bbox_new$xmax - bbox_new$xmin # range of x values
    yrange <- bbox_new$ymax - bbox_new$ymin # range of y values
    bbox_new[1] <- (bbox_new[1] - (justXmin * xrange)) # xmin - left
    bbox_new[3] <- bbox_new[3] + (justXmax * xrange) # xmax - right
    bbox_new[2] <- bbox_new[2] - (justYmin * yrange) # ymin - bottom
    bbox_new[4] <- bbox_new[4] + (justYmax * yrange) # ymax - top
    bbox_new <- bbox_new %>%  # take the bounding box ...
      st_as_sfc() # ... and make it a sf polygon
    return(bbox_new)}
  ######---------> TMAP: Over and underestimation of population    
  # Bbox of main map: 
  bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
  # Plot Denmark without Bornholm:
  map_percDif_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
    tm_polygons(col = "pop2018dif", 
                title = "Under/Overestimation\nErrors in %",
                midpoint = 0, 
                breaks = rounded_breaks, 
                palette = final_colors) + 
    tm_layout(bg.color = "#E1EEF2",
              legend.position = c("right", "top"),
              legend.bg.color = "white",
              title= "Weighted area interpolation\nusing exact densities",
              legend.title.size = 1.3,
              title.position = c("left", "top"),
              legend.frame = "grey60") 
  print(map_percDif_main)
  # Plot Bornholm map on top: 
  bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
  map_percDif_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
    tm_polygons(col = "pop2018dif", 
                legend.show = FALSE,
                midpoint = 0, 
                breaks = rounded_breaks, 
                palette = final_colors 
    ) + 
    tm_layout(frame = "grey60", 
              bg.color = "#D6EBF2" 
    )
  print(map_percDif_Born, 
        vp = grid::viewport(x = 0.71, y = 0.5,
                            width = 0.2, 
                            height = 0.2)
  )
  
  # KEY DENSITY COLUMN: estimated LAU population density in km2:  
  estimated_lau_pop$densKm2Est <- estimated_lau_pop$corPop / estimated_lau_pop$AREA_KM2 

  ###### FINAL TMAP 2A: Map with estimated population density --- NATURAL BREAKS     
  # Estimated population density     
  rounded_breaks <- c(15., 110., 250., 560., 880., 1420., 1780., 2360., 3240., 6730., 11982.)
  # breakvalues: Replace with min if lower than min(rounded_breaks)
  if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
    rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
  }
  # Add max if higher than max(rounded_breaks)
  if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
    rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
  }
######---------> TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#FFBA66", "#FF6600", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nusing exact densities",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#FFBA66", "#FF6600", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.71, y = 0.46,
                          width = 0.2, 
                          height = 0.2)
)

###### FINAL TMAP 2A: Map with estimated population density --- QUANTILE     
# Estimated population density     
rounded_breaks <- c(15., 50., 70., 80., 120., 160., 460., 1120., 11982.)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
######---------> TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nusing exact densities",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.71, y = 0.5,
                          width = 0.2, 
                          height = 0.2)
)

############## PRINT STATEMENTS ##############
######---------> PRINT     
##cat("Population 2018 total for NUTS is:", sum(NUTS2016withPop2018$y2018)) # NUTS NOT INPUTTED!!
cat("Population 2018 total for LAU is:", sum(LAU2018withPop2018$POP_2018))
cat("Population 2018 is estimated to be:", sum(estimated_lau_pop$corPop))
cat("Population 2018 total for LAU according to estimated data is:", sum(estimated_lau_pop$POP_2018))

# Print overall population: 
######---------> PRINT
cat("Overall percentage error:", sum(abs(estimated_lau_pop$pop2018dif)))
cat("Overall percentage error average:", sum(estimated_lau_pop$pop2018dif))
cat("Mean signed deviation or Bias:", bias(estimated_lau_pop$POP_2018, estimated_lau_pop$corPop))
cat("Mean absolute error:", mae(estimated_lau_pop$POP_2018, estimated_lau_pop$corPop))
cat("Median absolute error:", mdae(estimated_lau_pop$POP_2018, estimated_lau_pop$corPop))
cat("Mean squared error:", mse(estimated_lau_pop$POP_2018, estimated_lau_pop$corPop))
cat("Root mean squared error:", rmse(estimated_lau_pop$POP_2018, estimated_lau_pop$corPop))
cat("Mean absolute percentage error:", mape(estimated_lau_pop$POP_2018, estimated_lau_pop$corPop))







