# Install and import libraries: 
#install.packages("areal")
library(areal)
#install.packages("classInt")
library(classInt)
####install.packages("dplyr")
library(dplyr)
####install.packages("leafem")
library(leafem)
####install.packages("mapview")
library(mapview)
####install.packages("Metrics")
library(Metrics)
#install.packages("rstudioapi")
library(rstudioapi)
####install.packages("sf")
library(sf)
####install.packages("tmap")
library(tmap)
####install.packages("units")
library(units)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Avoid switching to darkmatter basemap but keep default lightgrey basemap when plotting: 
mapviewOptions(basemaps.color.shuffle = FALSE)

# Load spatial data:
NUTS2016withPop2018 <- st_read("data/NUTS_01M_DK2016Pop2018_2017.shp") #source
cor2018 <- st_read("data/cor18_DK_clippedToPop.shp")
LAU2018withPop2018 <- st_read("data/LAU_2018_01M_DK.shp") #target

# ID definitions: 
#NUTS ID is NUTS_ID
#NUTS Population 2018 column is y2018
#CorineID is Code_18
#Residential ID is created: ID_res = 1
#LAU ID is LAU_ID
#LAU area is AREA_KM2
#LAU population 2018 is POP_2018
#LAU population density 2018 is POP_DENS_2

# CORINE TO USE: 
#########---------> CHOOSE urban CORINE constellation codes: 
corine_list <- c("111", "112", "141")
#density: 
#111: 87.9 49.3%   #####    - Continuous urban fabric                     #URBAN FABRIC ->ALL CLASSES
#123: 24.6 13.8 %   ###3    Port areas                                    #INDUSTRIAL, COMERCIAL, TRANSPORT UNITS ->MINUS AIRPORTS
#122: 15.8 8.85 %    ##4    Road and rail networks and associated land    #INDUSTRIAL, COMERCIAL, TRANSPORT UNITS ->MINUS AIRPORTS
#141: 15.5 8.66 %   #5      - Green urban areas                           #ARTIFICAL NON-AGRICULTURAL VEGETATED AREAS ->MINUS SPORT AND LEISURE FACILITIES
#112: 12.8 7.19 %   #####   - Discontinuous urban fabric                  #URBAN FABRIC ->ALL CLASSES
#121: 8.13 4.55 %           Industrial or commercial units                #INDUSTRIAL, COMERCIAL, TRANSPORT UNITS ->MINUS AIRPORTS

######---------> MAPVIEW: NUTS and CORINE and LAU:
mapview(NUTS2016withPop2018) + mapview(cor2018) + mapview(LAU2018withPop2018)  

# new AREA COLUMN: calculate NUTS area in km2:
NUTS2016withPop2018$area_nuts <- set_units((st_area(NUTS2016withPop2018)), km^2)
#new DENSITY COLUMN: calculate overall population density per Ha for each nuts:  
NUTS2016withPop2018$densOvHa2018 <- NUTS2016withPop2018$y2018 / (NUTS2016withPop2018$area_nuts * 100) 

# DEFINE Function to make classification break values: 
make_equal_interval <- function(dataset_column_input, amount_intervals, style_type, rounded) {
  # Classify data using n intervals with the style method
  classifications <- classIntervals(dataset_column_input, n = amount_intervals, style = style_type)
  print(style_type)
  print(classifications)
  # Extract the breaks
  breaks <- classifications$brks
  print(breaks)
  # Calculate frequencies of data in each class
  frequencies <- tabulate(findInterval(dataset_column_input, breaks, rightmost.closed = TRUE))
  # Find breaks that result in non-empty classes
  non_empty_breaks <- breaks[frequencies > 0]
  # Round the breaks to divisible by 10 if rounded = TRUE otherwise round to three decimals after comma:
  if (rounded == TRUE) {
    non_empty_breaks <- round(non_empty_breaks, digits = -1)
  } else {
    non_empty_breaks <- round(non_empty_breaks, digits = 3)
  } 
  print(non_empty_breaks)
  # Add min(dataset_column_input) if lower than min(non_empty_breaks)
  if (min(dataset_column_input) < min(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == min(non_empty_breaks)] <- min(dataset_column_input)
  }
  # Add max(dataset_column_input) if higher than max(non_empty_breaks)
  if (max(dataset_column_input) > max(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == max(non_empty_breaks)] <- max(dataset_column_input)
  }
  non_empty_breaks <- sort(unique(non_empty_breaks))
  print(non_empty_breaks)
  return(non_empty_breaks)}
# Define colorpalette default: 
colors_default <- colorRampPalette(c("#FFFF00", "#990000"))  

######---------> MAPVIEW: Show NUTS area size: 
rounded_breaks = c(0, min(NUTS2016withPop2018$area_nuts), max(NUTS2016withPop2018$area_nuts)) #breakvalues
# Extract numeric values from the area catchment units column and store them in a new column
NUTS2016withPop2018$area_nuts_num <- as.numeric(gsub("[^0-9.]", "", NUTS2016withPop2018$area_nuts))
mapview(NUTS2016withPop2018, zcol = "area_nuts_num", col.regions = colors_default, at = rounded_breaks, layer.name="NUTS area in km2") %>%
  addStaticLabels(NUTS2016withPop2018,
                  NUTS2016withPop2018$area_nuts,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))
######---------> MAPVIEW: Show NUTS population: 
rounded_breaks = c(0, min(NUTS2016withPop2018$y2018), max(NUTS2016withPop2018$y2018)) #breakvalues
mapview(NUTS2016withPop2018, zcol = "y2018", col.regions = colors_default, at = rounded_breaks, layer.name="NUTS 2018 population") %>%
  addStaticLabels(NUTS2016withPop2018,
                  NUTS2016withPop2018$y2018,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))
######---------> MAPVIEW: Show NUTS population density: 
rounded_breaks = c(0, min(NUTS2016withPop2018$densOvHa2018), max(NUTS2016withPop2018$densOvHa2018)) #breakvalues
mapview(NUTS2016withPop2018, zcol = "densOvHa2018", col.regions = colors_default, at = rounded_breaks, layer.name="NUTS 2018 population density per ha") %>%
  addStaticLabels(NUTS2016withPop2018,
                  NUTS2016withPop2018$densOvHa2018,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))


############## PROCESSING OF CORINE DATA ##############
# Only pick residential areas from corine data: 
cor_subset <- cor2018[cor2018$Code_18 %in% corine_list,]
# Dissolve all residential corine polygon borders into one row (multipolygon):
cor_dissolved <- st_union(cor_subset) 
# Convert residential corine multipolygon to single features: 
cor_single <- st_cast(cor_dissolved, "POLYGON")
# Convert residential corine sf object to dataframe by moving geometry to column: 
cor_df <- st_drop_geometry(cor_single)
# Create new dataframe with one row and one column called ID_res:
attribute_table <- data.frame(ID_res = 1)
# Combine new attribute table with residential corine dataframe: 
cor_dissolved_att <- bind_cols(cor_df, attribute_table)
# Restore residential corine geometry by converting back from dataframe to sf object:
cor_dissolved <- st_sf(cor_dissolved_att)

######---------> MAPVIEW: RESIDENTIAL AREA: 
mapview(cor_dissolved, layer.name="corine residential")

# Calculate intersection of residential corine and nuts population (first intersection): 
intersection_cor <- st_intersection(cor_dissolved, NUTS2016withPop2018)

# Group features by NUTS_ID column, union geometries for each NUTS, and retain other attributes:
grouped_pop <- intersection_cor %>%
  group_by(NUTS_ID) %>%
  summarize(ID_res = first(ID_res),
            y2018 = first(y2018),
            geometry = st_union(...1)) #geometry column is called ...1

# New NUTS-CORINE columns per each NUTS area: 
# new AREA COLUMN: new residential area column calculating total residential area per each individual nuts:  
grouped_pop$area_res <- set_units((st_area(grouped_pop)), km^2)
# new DENSITY COLUMN: new pop18 density column describing residential population density for each nuts:  
grouped_pop$densityHa2018 <- grouped_pop$y2018 / (grouped_pop$area_res *100) 

######---------> MAPVIEW: RESIDENTIAL AREA in KM2 PER NUTS  
rounded_breaks <- c(0, round(min(grouped_pop$area_res), digits = -1), round(max(grouped_pop$area_res), digits = -1)) #breakvalues
mapview(grouped_pop, zcol = "area_res", col.regions = colors_default, 
        at = rounded_breaks, layer.name="total residential area in km2 per NUTS") %>%
  addStaticLabels(grouped_pop,
                  grouped_pop$area_res,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))
######---------> MAPVIEW: POPULATION DENSITY PER HA PER EACH NUTS 
rounded_breaks <- c(0, min(as.numeric(grouped_pop$densityHa2018))+1, (round(max(as.numeric(grouped_pop$densityHa2018)), digits = -1)+1)) #breakvalues
mapview(grouped_pop, zcol = "densityHa2018", col.regions = colors_default, 
        at = rounded_breaks, layer.name="population density 2018 in residential Ha per NUTS") %>%
  addStaticLabels(grouped_pop,
                  grouped_pop$densityHa2018,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))

# Convert residential corine dataset nuts multipolygon to single features for each residential area: 
single_popCor <- st_cast(grouped_pop, "POLYGON")

# New NUTS-CORINE columns Per residential area: 
# new AREA COLUMN: new residential area column calculating total residential area per each residential area:  
single_popCor$area_resres <- set_units((st_area(single_popCor)), km^2)
# new DENSITY COLUMN: new pop18 density column describing residential population density for each residential area:  
single_popCor$densResHa2018 <- single_popCor$y2018 / (single_popCor$area_resres *100) 

######---------> MAPVIEW: RESIDENTIAL AREA in KM2 PER RES  
rounded_breaks <- c(round(min(single_popCor$area_resres), digits = -1), round(max(single_popCor$area_resres), digits = -1)) #breakvalues
mapview(single_popCor, zcol = "area_resres", col.regions = colors_default, 
        at = rounded_breaks, layer.name="total residential area in km2 per residential area") %>%
  addStaticLabels(single_popCor,
                  single_popCor$area_resres,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))
######---------> MAPVIEW: POPULATION DENSITY PER HA PER EACH RESIDENTIAL AREA 
rounded_breaks <- c(0, min(as.numeric(single_popCor$densResHa2018))+1, (round(max(as.numeric(single_popCor$densResHa2018)), digits = -1)+1)) #breakvalues
mapview(single_popCor, zcol = "densResHa2018", col.regions = colors_default, 
        at = rounded_breaks, layer.name="population density 2018 in residential Ha per residential area") %>%
  addStaticLabels(single_popCor,
                  single_popCor$densResHa2018,
                  noHide = TRUE,
                  textsize = "12px",
                  style = list("background-color" = "white", "font-weight" = "bold"))


############## AREA INTERPOLATION ##############
# Perform areal-weighted interpolation of the 'population' attribute
estimated_lau_pop <- aw_interpolate(
  .data = LAU2018withPop2018, #referred to as target elsewhere
  tid = "LAU_ID", #id column in target
  source = grouped_pop,
  sid = "NUTS_ID", #id column in source
  weight = "sum", #should be sum for intensive vs. extensive interpolations
  output = "sf",
  extensive = c("y2018", "area_res") #attribute in source to interpolate 
)

#print(table(estimated_lau_pop$y2018))
#sum(estimated_lau_pop$y2018)
# replace NA with 0 in estimated pop
estimated_lau_pop$y2018[is.na(estimated_lau_pop$y2018)] <- 0
# replace NA with 0 in estimated area
estimated_lau_pop$area_res[is.na(estimated_lau_pop$area_res)] <- 0

############## COMPARE WITH LAU ##############
######---------> MAPVIEW: CORINE RESIDENTIAL AREA CUT PER POLYGON CUT PER LAU -- RESULT OF PREVIOUS 
######+++++ LAU DETAILS: AREA + POPULATION + DENSITY   
rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$area_res), 4, "jenks", rounded = FALSE) #breakvalues
# Extract numeric values from the area units column and store them in a new column
estimated_lau_pop$area_res_num <- as.numeric(gsub("[^0-9.]", "", estimated_lau_pop$area_res))
map_list <- c(mapview(estimated_lau_pop, zcol = "area_res_num", col.regions = colors_default, 
        at = rounded_breaks, layer.name="Residential corine area per polygon in km2 cut by LAU",
        alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$AREA_KM2), 4, "equal", rounded = TRUE) #breakvalues
# Extract numeric values from the area units column and store them in a new column
LAU2018withPop2018$AREA_KM2_num <- as.numeric(gsub("[^0-9.]", "", LAU2018withPop2018$AREA_KM2))
map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "AREA_KM2_num", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="LAU area in km2",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$POP_2018), 4, "equal", rounded = TRUE) #breakvalues
map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "POP_2018", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="LAU population 2018",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(LAU2018withPop2018$POP_DENS_2), 4, "jenks", rounded = FALSE) #breakvalues
map_list <- c(map_list, mapview(LAU2018withPop2018, zcol = "POP_DENS_2", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="LAU population density per km2 in 2018",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)

######---------> MAPVIEW: stated population per LAU + estimated population per LAU  
rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$POP_2018), 4, "jenks", rounded = FALSE) #breakvalues
map_list <- c(mapview(estimated_lau_pop, zcol = "POP_2018", col.regions = colors_default, 
                      at = rounded_breaks, layer.name="LAU population 2018",
                      alpha.regions = 0.75))
Reduce(`+`, map_list)
rounded_breaks <- make_equal_interval(as.numeric(estimated_lau_pop$y2018), 4, "jenks", rounded = FALSE) #breakvalues
map_list <- c(map_list, mapview(estimated_lau_pop, zcol = "y2018", col.regions = colors_default, 
                                at = rounded_breaks, layer.name="Estimated population 2018 per LAU",
                                alpha.regions = 0.75))
Reduce(`+`, map_list)

# Calculate percentage overestimation (marked with plus) or underestimation (marked with minus) of estimated population 
estimated_lau_pop$pop2018dif <- ((-(estimated_lau_pop$POP_2018 - as.numeric(estimated_lau_pop$y2018)) / estimated_lau_pop$POP_2018) *100.)

###### FINAL TMAP 1: Map with over and underestimations     
# Specify final classification and colors 
#Specify percentage interval to use as classification: 
rounded_breaks <- c(min(estimated_lau_pop$pop2018dif), -50, -30, -20, -10, -5, 0, 5, 10, 20, 30, 50, max(estimated_lau_pop$pop2018dif))
#colorpalette for this percentage interval: 
colors_much_below_zero <- colorRampPalette(c("#C06463", "#FD9763"))  # Light red to dark red
colors_below_zero <- colorRampPalette(c("#DDC511", "#FDFD63"))  # Light yellow to dark yellow #overestimation #FBDA62
colors_above_zero <- colorRampPalette(c("#B2DDFC", "#648BD7"))  # Light yellow to dark yellow #7A9BDC
colors_much_above_zero <- colorRampPalette(c("#AF4EB6", "#7D4195"))  # Light yellow to dark yellow ##7669D3 #5548A6
#Generate number of colors needed: 
num_colors_much_below <- 2 # sum(rounded_breaks < -30)
num_colors_below <- 4 # sum(rounded_breaks <= 5)
num_colors_above <- 4
num_colors_much_above <- 2 #sum(rounded_breaks > 30)
#create specific color palettes: 
colors_much_below <- colors_much_below_zero(num_colors_much_below)
colors_below <- colors_below_zero(num_colors_below)
colors_above <- colors_above_zero(num_colors_above)
colors_much_above <- colors_much_above_zero(num_colors_much_above)
#Concatenate the two lists
final_colors <- c(colors_much_below, colors_below, colors_above, colors_much_above)
# DEFINE Function to make classification break values: 
create_bbox <- function(dataset_input, justXmin, justXmax, justYmin, justYmax) {
  bbox_new <- st_bbox(dataset_input)
  xrange <- bbox_new$xmax - bbox_new$xmin # range of x values
  yrange <- bbox_new$ymax - bbox_new$ymin # range of y values
  bbox_new[1] <- (bbox_new[1] - (justXmin * xrange)) # xmin - left
  bbox_new[3] <- bbox_new[3] + (justXmax * xrange) # xmax - right
  bbox_new[2] <- bbox_new[2] - (justYmin * yrange) # ymin - bottom
  bbox_new[4] <- bbox_new[4] + (justYmax * yrange) # ymax - top
  bbox_new <- bbox_new %>%  # take the bounding box ...
    st_as_sfc() # ... and make it a sf polygon
  return(bbox_new)}
######---------> TMAP: Over and underestimation of population    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_percDif_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "pop2018dif", 
              title = "Under/Overestimation\nErrors in %",
              midpoint = 0, 
              breaks = rounded_breaks, 
              palette = final_colors) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Binary area interpolation\nwith 3 CORINE classes",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_percDif_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_percDif_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "pop2018dif", 
              legend.show = FALSE,
              midpoint = 0, 
              breaks = rounded_breaks, 
              palette = final_colors 
  ) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_percDif_Born, 
      vp = grid::viewport(x = 0.71, y = 0.5,
                          width = 0.2, 
                          height = 0.2)
)

# KEY DENSITY COLUMN: estimated LAU population density in km2:  
estimated_lau_pop$densKm2Est <- estimated_lau_pop$y2018 / estimated_lau_pop$AREA_KM2 

###### FINAL TMAP 2A: Map with estimated population density --- NATURAL BREAKS     
# Estimated population density     
rounded_breaks <- c(15., 110., 250., 560., 880., 1420., 1780., 2360., 3240., 6730., 11982.)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
######---------> TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#FFBA66", "#FF6600", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Binary area interpolation\nwith 3 CORINE classes",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#FFBA66", "#FF6600", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.71, y = 0.46,
                          width = 0.2, 
                          height = 0.2)
)

###### FINAL TMAP 2A: Map with estimated population density --- QUANTILE     
# Estimated population density     
rounded_breaks <- c(15., 50., 70., 80., 120., 160., 460., 1120., 11982.)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
######---------> TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Binary area interpolation\nwith 3 CORINE classes",
            legend.title.size = 1.3,
            title.position = c("left", "top"),
            legend.frame = "grey60") 
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.71, y = 0.5,
                          width = 0.2, 
                          height = 0.2)
)

############## PRINT STATEMENTS ##############
######---------> PRINT     
cat("Population 2018 total for NUTS is:", sum(NUTS2016withPop2018$y2018))
cat("Population 2018 total for LAU is:", sum(LAU2018withPop2018$POP_2018))
cat("Population 2018 is estimated to be:", sum(estimated_lau_pop$y2018))
cat("Population 2018 total for LAU according to estimated data is:", sum(estimated_lau_pop$POP_2018))

# Print overall population: 
######---------> PRINT
cat("Overall percentage error:", sum(abs(estimated_lau_pop$pop2018dif)))
cat("Overall percentage error average:", sum(estimated_lau_pop$pop2018dif))
cat("Mean signed deviation or Bias:", bias(estimated_lau_pop$POP_2018, estimated_lau_pop$y2018))
cat("Mean absolute error:", mae(estimated_lau_pop$POP_2018, estimated_lau_pop$y2018))
cat("Median absolute error:", mdae(estimated_lau_pop$POP_2018, estimated_lau_pop$y2018))
cat("Mean squared error:", mse(estimated_lau_pop$POP_2018, estimated_lau_pop$y2018))
cat("Root mean squared error:", rmse(estimated_lau_pop$POP_2018, estimated_lau_pop$y2018))
cat("Mean absolute percentage error:", mape(estimated_lau_pop$POP_2018, estimated_lau_pop$y2018))







