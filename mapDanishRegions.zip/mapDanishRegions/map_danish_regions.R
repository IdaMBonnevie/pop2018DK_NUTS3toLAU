library(tmap)

colors_chosen <- colorRampPalette(c("#FFCC00", 
                                    "#9BBB59",
                                    "#00B050", 
                                    "#8064A2", 
                                    "#B3A2C7", 
                                    "#CCC1DA", 
                                    "#2C4D75",
                                    "#31859C",
                                    "#93CDDD",
                                    "#DBEEF4", 
                                    "#FF6600", 
                                    "#C0504D"))  

map_regions <- tm_shape(estimated_lau_pop) + #DATASET
  tm_polygons(col = "pop2018dif", #COLUMNNAME 
              legend.show = FALSE,
              palette = final_colors 
  ) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_regions)
      